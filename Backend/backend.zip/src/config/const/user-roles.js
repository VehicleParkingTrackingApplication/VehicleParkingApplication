const USER_ROLES = {
    "admin": 5150,
    "staff": 1984,
    "user": 2001
}
export default roleList;